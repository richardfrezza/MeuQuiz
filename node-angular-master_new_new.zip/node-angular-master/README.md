# node-angular
Modelo de aplicação para o curso de Javascript com back-end em Node JS + Express + Mongoose e front-end em Angular + Bootstrap
